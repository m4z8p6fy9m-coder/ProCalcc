import test from'node:test';import assert from'node:assert/strict';import{evaluateExpression,formatNumber}from'../src/engine.js';
test('respects precedence',()=>assert.equal(evaluateExpression('2+3×4'),14));
test('supports powers and parentheses',()=>assert.equal(evaluateExpression('(2+3)^2'),25));
test('supports constants and implicit multiplication',()=>assert.ok(Math.abs(evaluateExpression('2π')-2*Math.PI)<1e-12));
test('calculates trig in degrees',()=>assert.ok(Math.abs(evaluateExpression('sin(30)','DEG')-.5)<1e-12));
test('calculates trig in radians',()=>assert.ok(Math.abs(evaluateExpression('sin(π÷2)','RAD')-1)<1e-12));
test('supports logarithms',()=>assert.equal(evaluateExpression('log(100)+ln(e)'),3));
test('rejects division by zero',()=>assert.throws(()=>evaluateExpression('1÷0')));
test('formats decimal comma',()=>assert.equal(formatNumber(1.25),'1,25'));
